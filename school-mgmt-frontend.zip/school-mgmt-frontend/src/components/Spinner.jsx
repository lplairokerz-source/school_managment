import React from 'react'
export default () => <div className='spinner'>Loading...</div>
